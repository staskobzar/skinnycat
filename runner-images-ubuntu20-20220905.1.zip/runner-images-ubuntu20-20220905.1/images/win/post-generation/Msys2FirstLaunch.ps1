# create user profile at the first launch
$null = cmd /c "C:\msys64\usr\bin\bash.exe -leo pipefail -c 'echo $SHELL' 2>&1"